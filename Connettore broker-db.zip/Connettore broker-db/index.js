const mqtt = require('mqtt')
require('dotenv').config()
const mySql = require('mysql')
const host = process.env.HOST
const user = process.env.USER
const password = process.env.PASSWORD
const database = process.env.DATABASE
const topic = "mytest/"
const client = mqtt.connect("mqtt://192.168.101.10");

fromMqttToDB();
//test()

function fromMqttToDB() {

//CONNESSIONE A SQL
var connection = mySql.createConnection({
  host: host,
  user: user,
  password: password,
  database: database
});

connection.connect(function (err) {
  if (err) throw err;
  console.log("Connected!");
})

client.on("connect", () => {
  client.subscribe(topic, (err) => {
    if (err) {
      console.log(err)
    }
    client.subscribe('mytest/');
  });
});

  client.on("message", (topic, message) => {
    // message is Buffer
    console.log(message.toString())
    var dejson = JSON.parse(message)
    console.log(dejson)
    var timestamp = dejson.timestamp
    var machineId = dejson.machine_id
    var bladeSpeed = dejson.BladeSpeed
    var temperature = dejson.Temperature
    var vibration = dejson.Vibration
    var powerStatus = dejson.PowerStatus
    var operationMode = dejson.OperationMode
    var errorStatus = dejson.ErrorStatus
    var pieceCount = dejson.PieceCount
    var sql = `INSERT INTO machine_data_replica(timestamp, machine_id, blade_speed, temperature, vibration, power_status, operation_mode, error_status, place_count) VALUES ("${timestamp}", "${machineId}", "${bladeSpeed}", "${temperature}", "${vibration}", "${powerStatus}", "${operationMode}", "${errorStatus}", "${pieceCount}");`
    connection.query(sql, function (err, result) {
      if (err) throw err;
      console.log("Record inserted");
    });
    //connection.end()
  });
}

// A little test

function test() {
  var date = new Date()
  var year = date.getFullYear()
  var month = date.getMonth() + 1
  var day = date.getDate()
  var hour = date.getHours()
  var min = date.getMinutes()
  var sec = date.getSeconds()
  var dateTime = year + "-" + month + "-" + day + " " + hour + ":" + min + ":" + sec
  console.log(dateTime)
  var data = {
    "timestamp": dateTime,
    "machine_id": 1,
    "machine_name": "Machine A",
    "temperature": 72.1,
    "pressure": 8.31,
    "speed": 1919.65,
    "vibration": 0.91,
    "status": "AllGoood"
  };
  var json = JSON.stringify(data)
  var dejson = JSON.parse(json)
  var timestamp = dejson.timestamp
  var machineId = dejson.machine_id
  var machineName = dejson.machine_name
  var temp = dejson.temperature
  var pressure = dejson.pressure
  var speed = dejson.speed
  var vibration = dejson.vibration
  var status = dejson.status
  console.log(json)
  var sql = `INSERT INTO machine_data(timestamp, machine_id, machine_name, temperature, pressure, speed, vibration, status) VALUES ("${timestamp}", "${machineId}", "${machineName}", "${temp}", "${pressure}", "${speed}", "${vibration}", "${status}");`
  connection.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Record inserted");
  });
}





