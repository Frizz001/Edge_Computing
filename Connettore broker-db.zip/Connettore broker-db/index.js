const express = require('express')
const mqtt = require('mqtt')
require('dotenv').config()
const mySql = require('mysql')
const router = express.Router()
const host = process.env.HOST
const user = process.env.USER
const password = process.env.PASSWORD
const database = process.env.DATABASE

const client = mqtt.connect("mqtt://192.168.101.16", {clientId: 'emanuele'});

const topic = "mytest/"

var connection = mySql.createConnection({
    host     : host,
    user     : user,
    password : password,
    database : database
  });

client.on("connect", () => {
  console.log('connesso')
  client.subscribe(topic, (err) => {
    if(err){
      console.log(err)
    }
    //client.subscribe('mytest/');
  });
});

var timestamp;
var machineId;
var machineName;
var temp;
var pressure;
var speed;
var vibration;
var status;

client.on("message", (topic, message) => {
    // message is Buffer
    console.log(message.toString())
    var json = JSON.parse(message)
    timestamp = json.timestamp
    machineId = json.machine_id 
    machineName =json.machine_name 
    temp = json.temperature 
    pressure = json.pressure 
    speed = json.speed 
    vibration = json.vibration 
    status = json.status 
    console.log(machineName, speed, vibration, status)
      connection.connect(function(err) {
        if (err) throw err;
        console.log("Connected!");
        var sql = `INSERT INTO machine_data(timestamp, machine_id, machine_name, temperature, pressure, speed, vibration, status)VALUES (${timestamp},${machineId},${machineName},${temp},${pressure},${speed},${vibration},${status})`;
        connection.query(sql, function (err, result) {
          if (err) throw err;
          console.log("1 record inserted");
        });
    })
    //client.end()
});







